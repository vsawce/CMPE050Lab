#ifndef FIGURE_H
#define FIGURE_H

using namespace std;

class Figure
{
    public:
        Figure();
        virtual void erase();
        virtual void draw();
        virtual void center();
};

#endif //FIGURE_H

//EXPLANATION IN LAB9_2.CPP
